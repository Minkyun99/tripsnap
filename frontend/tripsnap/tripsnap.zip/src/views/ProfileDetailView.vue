<template>
  <ProfileBase mode="other" />
</template>

<script setup>
import ProfileBase from './ProfileBase.vue'
</script>
