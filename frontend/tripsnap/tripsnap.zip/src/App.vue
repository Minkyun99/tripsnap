<script setup>
import Banner from './components/Banner.vue'
</script>

<template>
  <div class="app-shell">
    <Banner />
    <main class="app-main">
      <router-view />
    </main>
  </div>
</template>

<style scoped>
.app-main {
  padding: 24px 16px;
}
</style>
