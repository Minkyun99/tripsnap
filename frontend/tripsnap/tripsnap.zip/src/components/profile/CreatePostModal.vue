<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  open: { type: Boolean, default: false },
})

const emit = defineEmits(['close', 'submit'])

const title = ref('')
const content = ref('')
const file = ref(null)

watch(
  () => props.open,
  (v) => {
    if (v) {
      title.value = ''
      content.value = ''
      file.value = null
    }
  },
)

const onPick = (e) => {
  file.value = e.target.files?.[0] || null
}

const submit = () => {
  emit('submit', { title: title.value.trim(), content: content.value.trim(), file: file.value })
}
</script>

<template>
  <div v-if="open" class="ts-overlay" @click.self="emit('close')">
    <div class="ts-modal-sm pixel-corners">
      <button class="ts-x" type="button" @click="emit('close')">✕</button>

      <h3 class="ts-title">게시글 작성</h3>

      <div class="ts-form">
        <input class="ts-input" v-model="title" placeholder="제목 입력" />
        <textarea class="ts-textarea" v-model="content" rows="3" placeholder="내용 작성"></textarea>
        <input class="ts-input" type="file" @change="onPick" />

        <div class="ts-actions">
          <button class="ts-btn ts-btn--white" type="button" @click="emit('close')">취소</button>
          <button class="ts-btn ts-btn--pink" type="button" @click="submit">게시글 올리기</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
$ts-border-brown: #d2691e;
$ts-cream: #fff5e6;
$ts-pink: #ff69b4;
$ts-pink-hover: #ff1493;

.ts-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  display: grid;
  place-items: center;
  padding: 1rem;
  z-index: 60;
}

.ts-modal-sm {
  width: 100%;
  max-width: 36rem;
  background: #fff;
  border-radius: 1.25rem;
  border: 4px solid $ts-border-brown;
  padding: 1.25rem;
  position: relative;
  box-shadow: 0 26px 70px rgba(0, 0, 0, 0.22);
}

.ts-x {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 36px;
  height: 36px;
  border-radius: 999px;
  border: none;
  background: rgba(0, 0, 0, 0.6);
  color: #fff;
  cursor: pointer;
}

.ts-title {
  margin: 0 0 0.9rem;
  color: $ts-border-brown;
  font-weight: 900;
  font-size: 1.25rem;
}

.ts-form {
  background: $ts-cream;
  border-radius: 1rem;
  padding: 1rem;
  display: grid;
  gap: 0.75rem;
  border: 1px solid rgba(210, 105, 30, 0.35);
}

.ts-input,
.ts-textarea {
  width: 100%;
  border-radius: 0.75rem;
  border: 1px solid rgba(0, 0, 0, 0.18);
  padding: 0.65rem 0.85rem;
  background: #fff;
}

.ts-actions {
  display: flex;
  gap: 0.6rem;
  justify-content: flex-end;
}

.ts-btn {
  padding: 0.65rem 1rem;
  border-radius: 0.75rem;
  font-weight: 900;
  border: 2px solid $ts-border-brown;
  cursor: pointer;
}

.ts-btn--pink {
  background: $ts-pink;
  color: #fff;

  &:hover {
    background: $ts-pink-hover;
  }
}

.ts-btn--white {
  background: #fff;
  color: #6b4f2a;
}
</style>
