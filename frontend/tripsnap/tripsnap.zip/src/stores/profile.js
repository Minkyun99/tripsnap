// src/stores/profile.js
import { defineStore } from 'pinia'
import { getCsrfToken } from '@/utils/csrf'

const API = import.meta.env.VITE_API_BASE || ''

async function request(url, options = {}) {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'X-Requested-With': 'XMLHttpRequest',
      ...(options.headers || {}),
    },
    ...options,
  })

  // JSON 응답 가정(우리는 AJAX면 JSON 반환하도록 백엔드 분기 추가함)
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const msg = data?.error || data?.detail || '요청 처리 중 오류가 발생했습니다.'
    throw new Error(msg)
  }
  return data
}

export const useProfileStore = defineStore('profile', {
  state: () => ({
    loading: false,
    error: null,

    targetUser: null,
    profile: null,
    posts: [],

    isOwner: false,
    isFollowing: false,
    followerCount: 0,
    followingCount: 0,
    likedPostIds: [],

    // 댓글 캐시: postId -> comments[]
    commentsByPostId: {},
  }),

  actions: {
    async fetchProfile(nickname = '') {
      this.loading = true
      this.error = null
      try {
        const url = nickname
          ? `${API}/users/profile/${encodeURIComponent(nickname)}/`
          : `${API}/users/profile/`

        const data = await request(url)

        this.targetUser = data.target_user
        this.profile = data.profile
        this.posts = data.posts || []
        this.isOwner = !!data.is_owner
        this.isFollowing = !!data.is_following
        this.followerCount = data.follower_count ?? 0
        this.followingCount = data.following_count ?? 0
        this.likedPostIds = data.liked_post_ids ?? []
      } catch (e) {
        this.error = e.message
        throw e
      } finally {
        this.loading = false
      }
    },

    async searchProfile(q) {
      // users/profile/search/?q=
      const data = await request(`${API}/users/profile/search/?q=${encodeURIComponent(q)}`)
      return data // {found:true, nickname:'...'}
    },

    async toggleFollow(nickname) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/follow/${encodeURIComponent(nickname)}/ajax/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken },
      })
      this.isFollowing = !!data.is_following
      this.followerCount = data.follower_count ?? this.followerCount
      return data
    },

    async createPost({ title, content, file }) {
      const form = new FormData()
      form.append('title', title || '')
      form.append('content', content || '')
      if (file) form.append('share_trip', file)

      // Django는 multipart면 CSRF를 폼에서 받는 경우도 있지만,
      // 우리는 세션+csrftoken 쿠키 기반이므로 헤더로도 함께 보냄
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/post/create/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken },
        body: form,
      })

      // 새로고침 대신 목록에 반영(간단 정책: 프로필 재조회)
      await this.fetchProfile(this.targetUser?.nickname ? this.targetUser.nickname : '')
      return data
    },

    async deletePost(postId) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/post/${postId}/delete/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken },
      })
      this.posts = this.posts.filter((p) => p.id !== postId)
      delete this.commentsByPostId[postId]
      return data
    },

    async toggleLike(postId) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/post/${postId}/like-toggle/ajax/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken },
      })

      // 화면 즉시 반영: like_count & likedPostIds
      const idx = this.posts.findIndex((p) => p.id === postId)
      if (idx !== -1) {
        this.posts[idx].like_count = data.like_count
      }
      if (data.is_liked) {
        if (!this.likedPostIds.includes(postId)) this.likedPostIds.push(postId)
      } else {
        this.likedPostIds = this.likedPostIds.filter((id) => id !== postId)
      }

      return data
    },

    async fetchComments(postId) {
      const data = await request(`${API}/users/post/${postId}/comments/ajax/`)
      this.commentsByPostId[postId] = data.comments || []
      return data
    },

    async createComment(postId, content) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/post/${postId}/comments/ajax/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrftoken,
        },
        body: JSON.stringify({ content }),
      })

      // 새 댓글 즉시 추가
      if (data.success && data.comment) {
        if (!this.commentsByPostId[postId]) this.commentsByPostId[postId] = []
        this.commentsByPostId[postId].push(data.comment)

        const idx = this.posts.findIndex((p) => p.id === postId)
        if (idx !== -1) this.posts[idx].comment_count = (this.posts[idx].comment_count || 0) + 1
      }

      return data
    },

    async deleteComment(commentId, postId) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/comment/${commentId}/delete/ajax/`, {
        method: 'POST',
        headers: { 'X-CSRFToken': csrftoken },
      })

      this.commentsByPostId[postId] = (this.commentsByPostId[postId] || []).filter(
        (c) => c.id !== commentId,
      )

      const idx = this.posts.findIndex((p) => p.id === postId)
      if (idx !== -1)
        this.posts[idx].comment_count = Math.max(0, (this.posts[idx].comment_count || 1) - 1)

      return data
    },

    async updateComment(commentId, postId, newContent) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/comment/${commentId}/edit/ajax/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrftoken,
        },
        body: JSON.stringify({ content: newContent }),
      })

      const list = this.commentsByPostId[postId] || []
      const idx = list.findIndex((c) => c.id === commentId)
      if (idx !== -1) list[idx].content = data.content

      return data
    },

    async fetchFollowers(nickname) {
      return await request(`${API}/users/profile/${encodeURIComponent(nickname)}/followers/ajax/`)
    },

    async fetchFollowings(nickname) {
      return await request(`${API}/users/profile/${encodeURIComponent(nickname)}/followings/ajax/`)
    },

    async uploadProfileImage(base64Image) {
      const csrftoken = getCsrfToken()
      const data = await request(`${API}/users/upload-profile-image/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrftoken,
        },
        body: JSON.stringify({ image: base64Image }),
      })
      // 프로필 재조회(이미지 갱신)
      await this.fetchProfile()
      return data
    },
  },
})
