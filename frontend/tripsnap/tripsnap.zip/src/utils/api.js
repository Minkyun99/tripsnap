// src/utils/api.js
import { getCsrfToken } from './csrf'

const API_BASE = import.meta.env.VITE_API_BASE || ''

async function ensureCsrfCookie() {
  // Django에서 ensure_csrf_cookie가 걸린 아무 GET 엔드포인트를 한번 호출해 쿠키를 세팅
  // 프로젝트에 맞게 교체 가능: 예) /api/auth/user/ , /chatbot/chat/ 등
  await fetch(`${API_BASE}/api/auth/user/`, { credentials: 'include' }).catch(() => {})
}

export async function apiFetch(path, options = {}) {
  const url = path.startsWith('http') ? path : `${API_BASE}${path}`

  const method = (options.method || 'GET').toUpperCase()
  const headers = new Headers(options.headers || {})

  // POST/PUT/PATCH/DELETE면 CSRF 필요
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
    let token = getCsrfToken()
    if (!token) {
      await ensureCsrfCookie()
      token = getCsrfToken()
    }
    if (token) headers.set('X-CSRFToken', token)
  }

  const res = await fetch(url, {
    ...options,
    method,
    headers,
    credentials: 'include',
  })

  return res
}

export async function apiJson(path, options = {}) {
  const res = await apiFetch(path, options)
  let data = null
  const ct = res.headers.get('content-type') || ''
  if (ct.includes('application/json')) {
    data = await res.json().catch(() => null)
  }
  if (!res.ok) {
    const msg = data?.detail || data?.error || '요청 처리 중 오류가 발생했습니다.'
    throw new Error(msg)
  }
  return data
}
